package my.spring4.domain;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;

@Entity
@DynamicUpdate
@Table(name = "teacher")
public class Teacher extends BaseEntity {
	private String name;
	
	@OneToMany(mappedBy = "teacher")
	private List<Course> courses=new ArrayList<Course>();
	
	public Teacher() {
		
	}
	public Teacher(String name) {
		
		this.name = name;
		
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<Course> getCourses() {
		return courses;
	}
	public void setCourses(List<Course> courses) {
		this.courses = courses;
	}
	


}
