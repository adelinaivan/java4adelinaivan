package my.spring4.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.NoRepositoryBean;
import org.springframework.stereotype.Repository;

import my.spring4.domain.Log;

@Repository
public interface LogRepository extends JpaRepository<Log, Long> {
}
