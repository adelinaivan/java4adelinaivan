package my.spring4.repo;



import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import my.spring4.domain.Course;


@Repository
public interface CourseRepository extends JpaRepository<Course, Long> {

	Course getByName(String name);
	
	@Cacheable("courses")
	Course getById(Long id);
}
