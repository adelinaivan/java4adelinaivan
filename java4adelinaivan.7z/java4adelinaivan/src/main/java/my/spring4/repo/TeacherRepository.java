package my.spring4.repo;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.NoRepositoryBean;
import org.springframework.stereotype.Repository;

import my.spring4.domain.Teacher;

@Repository
public interface TeacherRepository extends JpaRepository<Teacher, Long> {
	Teacher getByName(String name);

	Teacher getById(Long id);
}
