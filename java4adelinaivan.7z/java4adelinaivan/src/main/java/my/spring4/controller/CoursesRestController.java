package my.spring4.controller;

import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sun.org.apache.xerces.internal.impl.xpath.regex.ParseException;

import my.spring4.controller.dto.CourseDto;
import my.spring4.domain.Course;
import my.spring4.domain.Log;
import my.spring4.repo.CourseRepository;
import my.spring4.repo.LogRepository;
import my.spring4.repo.TeacherRepository;




@RestController
@RequestMapping("/rest/courses") //~= @Path din JAX-RS
@ComponentScan("{my.spring4.domain,my.spring4.dto,my.spring4.repo}")
public class CoursesRestController {


	@Autowired
	private CourseRepository courseRepo;
	
	@Autowired
	private TeacherRepository teacherRepo;
	
	@Autowired
	private LogRepository logRepo;
	
	@Autowired
	private CoursesFacade facade;
	
	// ~= @GET + @Path("/courses")
	@GetMapping 
	public List<CourseDto> getAllCourses() {
		List<CourseDto> dtos = new ArrayList<CourseDto>();
		for (Course course : courseRepo.findAll()) {
			dtos.add(mapToDto(course));
		}
		return dtos;
	}

	@GetMapping("{id}")
	public CourseDto getCourseById(@PathVariable Long id) { 
		return mapToDto(courseRepo.getById(id));
	}
	
	
	
	
	@PutMapping("{id}")
	@CacheEvict(cacheNames = "courses", allEntries = true)
	public void updateCourse(@PathVariable Long id, @RequestBody CourseDto dto) throws ParseException, java.text.ParseException {
		dto.id = id;
		updateCourse(dto);
		logRepo.save(new Log("Salut!,teacher"+teacherRepo.getById(dto.teacher_Id)));
		
	}


	
	@DeleteMapping("{id}")
	public void deleteCourseById(@PathVariable Long id) { 
		courseRepo.deleteById(id);
	}
	
	@PostMapping
	public void createCourse(@RequestBody CourseDto dto) throws ParseException, java.text.ParseException { 
		if (courseRepo.getByName(dto.name) != null) {
			throw new IllegalArgumentException("Another course with that name already exists");
		}
		courseRepo.save(mapToEntity(dto));
	}

	private CourseDto mapToDto(Course course) {
		CourseDto dto = new CourseDto();
		dto.id = course.getId();
		dto.name = course.getName();
		dto.keywords = course.getKeywords();
		dto.description = course.getDescription();
		dto.startDate = new SimpleDateFormat("dd-MM-yyyy").format(course.getStartDate());
		dto.teacher_Id = course.getTeacher().getId();
		

		dto.teacherName = course.getTeacher().getName();
		return dto ;
	}
	
	private Course mapToEntity(CourseDto dto) throws ParseException, java.text.ParseException {
		Course newEntity = new Course();
		
		newEntity.setName(dto.name);
		newEntity.setDescription(dto.description);
		newEntity.setKeywords(dto.description);
		newEntity.setTeacher(teacherRepo.getById(dto.teacher_Id));
		
		newEntity.setStartDate(new SimpleDateFormat("dd-MM-yyyy").parse(dto.startDate));
		
		return newEntity;
	}
	
	public void updateCourse(CourseDto dto) throws  java.text.ParseException  {
		if (courseRepo.getByName(dto.name) != null &&  
			!courseRepo.getByName(dto.name).getId().equals(dto.id)) {
			throw new IllegalArgumentException("Another course with that name already exists");
		}
		
		
		Course course = courseRepo.getById(dto.id);
		
		logRepo.save(new Log("Salut!,teacher"+dto.teacher_Id));
		course.setName(dto.name);
		course.setDescription(dto.description);
		course.setKeywords(dto.description);
		course.setStartDate(facade.parseDate(dto.startDate));
		course.setTeacher(teacherRepo.getById(dto.teacher_Id));
		course.setKeywords(dto.keywords);
	}
	
}
