package my.spring4.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import my.spring4.controller.dto.TeacherDto;
import my.spring4.domain.Teacher;
import my.spring4.repo.TeacherRepository;

@RestController
@RequestMapping("/rest/teachers")
@ComponentScan("{my.spring4.domain,my.spring4.dto,my.spring4.repo}")
public class TeachersRestController {
	@Autowired
	private TeacherRepository teacherRepo;
	
	@GetMapping 
	public List<TeacherDto> getAllTeachers() {
		List<TeacherDto> dtos = new ArrayList<TeacherDto>();	
		
		for (Teacher teacher : teacherRepo.findAll()) {
			dtos.add(mapToDto(teacher));
		}
		return dtos;
	}

	@GetMapping("{id}")
	public TeacherDto getTeacherById(@PathVariable Long id) { 
		return mapToDto(teacherRepo.getById(id));
	}
	private TeacherDto mapToDto(Teacher teacher) {
		TeacherDto dto = new TeacherDto();
		dto.id = teacher.getId();
		dto.name = teacher.getName();		
		return dto ;
	}
	
	
}
