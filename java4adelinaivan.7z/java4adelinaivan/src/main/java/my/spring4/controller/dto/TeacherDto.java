package my.spring4.controller.dto;

public class TeacherDto {
	public Long id;
	public String name;
	
	public TeacherDto() {
	}

	public TeacherDto(Long id, String name) {
		this.id = id;
		this.name = name;
	}
	
	
}
