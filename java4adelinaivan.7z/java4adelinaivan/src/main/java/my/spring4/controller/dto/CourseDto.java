package my.spring4.controller.dto;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class CourseDto {
	public Long id;
	public String name;
	public String keywords;
	public Long teacher_Id;
	public String teacherName;
	public String startDate;
	public String description;
	
}
