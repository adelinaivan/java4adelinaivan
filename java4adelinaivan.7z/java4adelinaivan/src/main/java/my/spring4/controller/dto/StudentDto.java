package my.spring4.controller.dto;

public class StudentDto {
	public Long id;
	public String name;
}
