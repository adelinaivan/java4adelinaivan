package my.spring4.controller;

import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import my.spring4.controller.dto.CourseDto;
import my.spring4.domain.Course;
import my.spring4.domain.Log;
import my.spring4.repo.CourseRepository;
import my.spring4.repo.LogRepository;
import my.spring4.repo.TeacherRepository;


@Service
@ComponentScan("{my.spring4.controller.dto,my.spring4.domain,my.spring4.repo}")
@Transactional
public class CoursesFacade {
	@Autowired
	private CourseRepository courseRepo;
	@Autowired
	private TeacherRepository teacherRepo;
	@Autowired
	private LogRepository logRepo;
	
	

	static Date parseDate(String dateStr) throws ParseException, java.text.ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		Date date = (Date) sdf.parse(dateStr);
		if (!sdf.format(date).equals(dateStr)) {
			throw new IllegalArgumentException("Invalid Date Format");
		}
		return date;
	}
	

}